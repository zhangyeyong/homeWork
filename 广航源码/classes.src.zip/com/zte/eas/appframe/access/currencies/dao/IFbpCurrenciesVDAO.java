package com.zte.eas.appframe.access.currencies.dao;

import com.zte.ssb.framework.base.DAO;
import java.util.List;

public abstract interface IFbpCurrenciesVDAO
  extends DAO
{
  public abstract List getFbpCurrencies();
}


/* Location:           C:\Users\zhangyeyong\Downloads\gdc_evs\evs\webapps\evs\WEB-INF\classes\
 * Qualified Name:     com.zte.eas.appframe.access.currencies.dao.IFbpCurrenciesVDAO
 * JD-Core Version:    0.7.0.1
 */