package com.zte.eas.appframe.access.wfFacade.dao;

import com.zte.ssb.framework.base.DAO;

public abstract interface IWfFacadeDAO
  extends DAO
{
  public abstract String approve(String paramString1, String paramString2, String paramString3, String paramString4);
}


/* Location:           C:\Users\zhangyeyong\Downloads\gdc_evs\evs\webapps\evs\WEB-INF\classes\
 * Qualified Name:     com.zte.eas.appframe.access.wfFacade.dao.IWfFacadeDAO
 * JD-Core Version:    0.7.0.1
 */