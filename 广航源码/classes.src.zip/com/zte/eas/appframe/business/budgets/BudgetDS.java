package com.zte.eas.appframe.business.budgets;

public class BudgetDS
  implements IBudgetDS
{
  public int expenseDeduct(String paramString)
  {
    return 1;
  }
  
  public int expenseReserve(String paramString)
  {
    return 1;
  }
  
  public int expenseRollback(String paramString)
  {
    return 1;
  }
  
  public int syncBudgetItem(String paramString)
  {
    return 1;
  }
  
  public int syncBudgetList(String paramString)
  {
    return 1;
  }
}


/* Location:           C:\Users\zhangyeyong\Downloads\gdc_evs\evs\webapps\evs\WEB-INF\classes\
 * Qualified Name:     com.zte.eas.appframe.business.budgets.BudgetDS
 * JD-Core Version:    0.7.0.1
 */