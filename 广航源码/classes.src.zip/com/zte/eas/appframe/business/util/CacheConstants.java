package com.zte.eas.appframe.business.util;

public class CacheConstants
{
  public static final String RECEIPT_METHODS = "RECEIPT_METHODS";
  public static final String MEMO_LINES = "MEMO_LINES";
  public static final String RECEIVABLES = "RECEIVABLES";
  public static final String LOOKUP_TYPE = "LOOKUP_TYPE";
  public static final String DEPTS_NAME = "DEPTS_NAME";
}


/* Location:           C:\Users\zhangyeyong\Downloads\gdc_evs\evs\webapps\evs\WEB-INF\classes\
 * Qualified Name:     com.zte.eas.appframe.business.util.CacheConstants
 * JD-Core Version:    0.7.0.1
 */