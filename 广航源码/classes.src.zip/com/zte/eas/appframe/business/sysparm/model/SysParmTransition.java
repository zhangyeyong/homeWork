package com.zte.eas.appframe.business.sysparm.model;

public class SysParmTransition
{
  public SieSysParm sieSysParm1 = new SieSysParm();
  public SieSysParm sieSysParm2 = new SieSysParm();
  public SieSysParm sieSysParm3 = new SieSysParm();
  public SieSysParm sieSysParm4 = new SieSysParm();
  public SieSysParm sieSysParm5 = new SieSysParm();
  
  public SieSysParm getSieSysParm5()
  {
    return this.sieSysParm5;
  }
  
  public void setSieSysParm5(SieSysParm paramSieSysParm)
  {
    this.sieSysParm5 = paramSieSysParm;
  }
  
  public SieSysParm getSieSysParm1()
  {
    return this.sieSysParm1;
  }
  
  public void setSieSysParm1(SieSysParm paramSieSysParm)
  {
    this.sieSysParm1 = paramSieSysParm;
  }
  
  public SieSysParm getSieSysParm2()
  {
    return this.sieSysParm2;
  }
  
  public void setSieSysParm2(SieSysParm paramSieSysParm)
  {
    this.sieSysParm2 = paramSieSysParm;
  }
  
  public SieSysParm getSieSysParm3()
  {
    return this.sieSysParm3;
  }
  
  public void setSieSysParm3(SieSysParm paramSieSysParm)
  {
    this.sieSysParm3 = paramSieSysParm;
  }
  
  public SieSysParm getSieSysParm4()
  {
    return this.sieSysParm4;
  }
  
  public void setSieSysParm4(SieSysParm paramSieSysParm)
  {
    this.sieSysParm4 = paramSieSysParm;
  }
}


/* Location:           C:\Users\zhangyeyong\Downloads\gdc_evs\evs\webapps\evs\WEB-INF\classes\
 * Qualified Name:     com.zte.eas.appframe.business.sysparm.model.SysParmTransition
 * JD-Core Version:    0.7.0.1
 */