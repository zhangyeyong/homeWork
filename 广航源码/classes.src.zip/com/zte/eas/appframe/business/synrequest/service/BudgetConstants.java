package com.zte.eas.appframe.business.synrequest.service;

public class BudgetConstants
{
  static final String DEPTSYNINF = "DEPT_SYNCH_INF";
  static final String EMPSYNINF = "SYNCH_EMPLOYEES_INFO";
  static final String BALANCE_COMPANY = "SYNCH_BALANCE_COMPANY";
  static final String ATTACHMENT = "SYNC_ATTACHMENT";
  static final String SYNC_VOUCHER = "SYNC_VOUCHER";
  static final String SYNC_IMAGE = "SYNC_IMAGE_EID_TO_EVS";
}


/* Location:           C:\Users\zhangyeyong\Downloads\gdc_evs\evs\webapps\evs\WEB-INF\classes\
 * Qualified Name:     com.zte.eas.appframe.business.synrequest.service.BudgetConstants
 * JD-Core Version:    0.7.0.1
 */