package com.zte.eas.appframe.importmis;

public class ImportUtil
{
  public static final String SUCCESS = "SUCCESS";
  public static final String FAILD = "FAILD";
}


/* Location:           C:\Users\zhangyeyong\Downloads\gdc_evs\evs\webapps\evs\WEB-INF\classes\
 * Qualified Name:     com.zte.eas.appframe.importmis.ImportUtil
 * JD-Core Version:    0.7.0.1
 */