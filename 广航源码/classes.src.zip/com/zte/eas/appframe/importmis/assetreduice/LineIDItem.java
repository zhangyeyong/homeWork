package com.zte.eas.appframe.importmis.assetreduice;

import java.io.Serializable;

public class LineIDItem
  implements Serializable
{
  protected String lineID;
  
  public String getLineID()
  {
    return this.lineID;
  }
  
  public void setLineID(String paramString)
  {
    this.lineID = paramString;
  }
}


/* Location:           C:\Users\zhangyeyong\Downloads\gdc_evs\evs\webapps\evs\WEB-INF\classes\
 * Qualified Name:     com.zte.eas.appframe.importmis.assetreduice.LineIDItem
 * JD-Core Version:    0.7.0.1
 */