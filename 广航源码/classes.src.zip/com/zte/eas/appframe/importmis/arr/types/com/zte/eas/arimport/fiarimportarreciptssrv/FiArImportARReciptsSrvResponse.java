package com.zte.eas.appframe.importmis.arr.types.com.zte.eas.arimport.fiarimportarreciptssrv;

import java.io.Serializable;

public class FiArImportARReciptsSrvResponse
  implements Serializable
{
  protected String result;
  
  public String getResult()
  {
    return this.result;
  }
  
  public void setResult(String paramString)
  {
    this.result = paramString;
  }
}


/* Location:           C:\Users\zhangyeyong\Downloads\gdc_evs\evs\webapps\evs\WEB-INF\classes\
 * Qualified Name:     com.zte.eas.appframe.importmis.arr.types.com.zte.eas.arimport.fiarimportarreciptssrv.FiArImportARReciptsSrvResponse
 * JD-Core Version:    0.7.0.1
 */