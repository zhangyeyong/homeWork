package com.zte.consts;

public class R_CJ000
{
  public static final String FBP_LOOKUP_SELECT = "fbp.lookup.select";
  public static final String VOCHER_CHECK_MSG1 = "vocher.check.msg1";
  public static final String YES = "vocher.check.yes";
  public static final String NO = "vocher.check.no";
  public static final String MATCHED = "vocher.check.matched";
  public static final String UNMATCH = "vocher.check.unmatch";
  public static final String SUBMITED = "vocher.check.submited";
  public static final String CHECKED = "vocher.check.checked";
  public static final String BACKED = "vocher.check.backed";
  public static final String BOOKED = "vocher.check.booked";
  public static final String UNBOOK = "vocher.check.unbook";
  public static final String PACKAGED = "vocher.check.packaged";
  public static final String UNPACKAG = "vocher.check.unpackag";
  public static final String ALREADY_RECEIVE = "vocher.check.already_receive";
  public static final String NOT_RECEIVE = "vocher.check.not_receive";
  public static final String ALREADY_FLITTING = "vocher.check.already_flitting";
  public static final String NOW_FLITTING = "vocher.check.now_flitting";
  public static final String BOOKED_NO_BOX = "vocher.check.booked_no_box";
  public static final String WAREHOUSE = "vocher.check.warehouse";
  public static final String BORROWING = "vocher.check.borrowing";
  public static final String PACKAGED_NO_INCOME = "vocher.check.packaged_no_income";
  public static final String NOT_PACKAGED = "vocher.check.not_packaged";
  public static final String CHECKED_NO_BOOKED = "vocher.check.checked_no_booked";
  public static final String REMOVE_FLITTING = "vocher.check.remove_flitting";
  public static final String RESTS = "vocher.check.rests";
  public static final String UNWAREHOUSE = "vocher.check.unwarehouse";
  public static final String UNPACK = "vocher.check.unpack";
  public static final String PACKAG = "vocher.check.packag";
  public static final String BACK = "vocher.check.back";
  public static final String CHECK = "vocher.check.check";
  public static final String SUBMIT = "vocher.check.submit";
  public static final String INSERTVOUCHER = "vocher.check.insertvoucher";
  public static final String UPDATEVOUCHER = "vocher.check.updatevoucher";
  public static final String UNBOOKS = "vocher.check.unbooks";
  public static final String BOOKEDS = "vocher.check.bookeds";
  public static final String MATCH = "vocher.check.match";
  public static final String EVS_VOUCHER_CHECK_SERVICE_MSG1 = "Evs.Voucher.Check.Service.msg1";
}


/* Location:           C:\Users\zhangyeyong\Downloads\gdc_evs\evs\webapps\evs\WEB-INF\classes\
 * Qualified Name:     com.zte.consts.R_CJ000
 * JD-Core Version:    0.7.0.1
 */