package com.cmcc.mss.msgheader;

import javax.xml.bind.annotation.XmlRegistry;

@XmlRegistry
public class ObjectFactory
{
  public MsgHeader createMsgHeader()
  {
    return new MsgHeader();
  }
}


/* Location:           C:\Users\zhangyeyong\Downloads\gdc_evs\evs\webapps\evs\WEB-INF\classes\
 * Qualified Name:     com.cmcc.mss.msgheader.ObjectFactory
 * JD-Core Version:    0.7.0.1
 */