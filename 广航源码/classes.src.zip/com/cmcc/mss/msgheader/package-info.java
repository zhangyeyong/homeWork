package com.cmcc.mss.msgheader;

import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;

@XmlSchema(namespace="http://mss.cmcc.com/MsgHeader", elementFormDefault=XmlNsForm.QUALIFIED)
abstract interface package-info {}


/* Location:           C:\Users\zhangyeyong\Downloads\gdc_evs\evs\webapps\evs\WEB-INF\classes\
 * Qualified Name:     com.cmcc.mss.msgheader.package-info
 * JD-Core Version:    0.7.0.1
 */