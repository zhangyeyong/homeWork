package com.cmcc.mss.sb_fi_ar_inquiryarjournalinfosrv;

import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;

@XmlSchema(namespace="http://mss.cmcc.com/SB_FI_AR_InquiryARJournalInfoSrv", elementFormDefault=XmlNsForm.QUALIFIED)
abstract interface package-info {}


/* Location:           C:\Users\zhangyeyong\Downloads\gdc_evs\evs\webapps\evs\WEB-INF\classes\
 * Qualified Name:     com.cmcc.mss.sb_fi_ar_inquiryarjournalinfosrv.package-info
 * JD-Core Version:    0.7.0.1
 */