package com.cmcc.mss.sb_eas_eas_importimageoperationinfosrv;

import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;

@XmlSchema(namespace="http://mss.cmcc.com/SB_EAS_EAS_ImportImageOperationInfoSrv", elementFormDefault=XmlNsForm.QUALIFIED)
abstract interface package-info {}


/* Location:           C:\Users\zhangyeyong\Downloads\gdc_evs\evs\webapps\evs\WEB-INF\classes\
 * Qualified Name:     com.cmcc.mss.sb_eas_eas_importimageoperationinfosrv.package-info
 * JD-Core Version:    0.7.0.1
 */