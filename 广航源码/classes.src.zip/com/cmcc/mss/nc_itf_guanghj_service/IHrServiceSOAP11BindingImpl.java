package com.cmcc.mss.nc_itf_guanghj_service;

import java.rmi.RemoteException;

public class IHrServiceSOAP11BindingImpl
  implements IHrServicePortType
{
  public String process(String paramString)
    throws RemoteException
  {
    return null;
  }
}


/* Location:           C:\Users\zhangyeyong\Downloads\gdc_evs\evs\webapps\evs\WEB-INF\classes\
 * Qualified Name:     com.cmcc.mss.nc_itf_guanghj_service.IHrServiceSOAP11BindingImpl
 * JD-Core Version:    0.7.0.1
 */